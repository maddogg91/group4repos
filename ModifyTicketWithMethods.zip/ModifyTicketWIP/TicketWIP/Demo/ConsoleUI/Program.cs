﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleUI
{

    public class Ticket
    {
        public string T_id { get; set; }
        public string Status { get; set; }
        public string E_id { get; set; }
        public string Priority { get; set; }
        public string Task { get; set; }
        public string C_id { get; set; }
        public string Date_created { get; set; }
        public Ticket(string id, string status, string employee, string priority, string task, string customer, string date)
        {
            T_id = id;
            Status = status;
            E_id = employee;
            Priority = priority;
            Task = task;
            C_id = customer;
            Date_created = date;
        }
    }


    class Program
    {

        //Generates the Primary Key for the ticket
        public static string GeneratePrimaryKey()
        {
            Random rand = new Random();
            int num = rand.Next(0, 99999);
            string pk = num.ToString("D5");
            return pk;
        }

        //Selects the current status based on user input
        public static string SelectStatus()
        {
            string status;
            bool run = false;

            if (run == true)
            {
                status = TestModifyStatus();
            }
            
            else
            {
                status = "Open";
                
            }
            switch (status)
            {
                case "closed":
                    {
                        string closed = "closed";
                        return closed;

                    }
                case "resolved":
                    {
                        string resolved = "resolved";
                        return resolved;
                    }
                default:
                    {
                        string open = "open";
                        return open;

                    }
            }
        }



        //method to create a ticket
        public static Ticket CreateDefaultTicket()
        {

            string key = GeneratePrimaryKey();
            string status = SelectStatus();
           
           
            //Create default ticket
            Ticket default_ticket = new Ticket(key, status, "employee ID", "unassigned", "SAMPLE TASK: THIS IS WHAT NEEDS TO BE DONE.", "CUSTOMER", "March 11th, 2019");
            
            return default_ticket;


        }



        //ticket implementor
        public static Ticket TicketImplementor()
        {
            Ticket newticket = CreateDefaultTicket();
            return newticket;
        }

        public static string UserTicketID()
        {
            Ticket ticket = TicketImplementor();
            string id = ticket.T_id;
            return id;
        }

        



        public static string UserTicketStatus()
        {
            Ticket ticket = CreateDefaultTicket();
            string status = ticket.Status;
            return status;
        }
        public static string ModifyTicketStatus()
        {
            string status = SelectStatus();
            return status;
        }


        public static void ViewTicket()
        {
            Ticket ticket = TicketImplementor();
            Console.WriteLine("Ticket #: {0}\n{1} {2} {3} {4} {5}\n{6}\n", ticket.T_id, ticket.Status, ticket.E_id, ticket.Priority, ticket.C_id, ticket.Date_created, ticket.Task);
            Console.ReadLine();

        }

        public static string TestModifyStatus()
        {
            Console.WriteLine("Enter Open, Closed, or Resolved");
            string input = Console.ReadLine();
            input = input.ToLower();
            return input;
        }

        //public static void Modify()
        //{
            

        //    Console.WriteLine("Create the a ticket?");
        //    string input = Console.ReadLine();
        //    switch (input)
        //    {
        //        case "yes":
                    
        //            break;

        //        default:
        //            break;
        //    }
        //}



            static void Main(string[] args)
        {
            bool newticket = true;
            do
            {
                ViewTicket();
                Console.WriteLine("Create new ticket");
                Console.Write(">");
                string input = Console.ReadLine();
                switch (input)
                {
                    case "yes":
                        newticket = true;
                        break;
                    default:
                        newticket = false;
                        break;
                        
                }
            } while (newticket == true);
               
               

           


            ////Modify Ticket 'Resolved'
            //Console.WriteLine("Resolved ticket?");
            //string input = Console.ReadLine();

        }

        }
    }


